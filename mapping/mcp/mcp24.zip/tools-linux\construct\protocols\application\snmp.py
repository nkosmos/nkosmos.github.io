"""
Simple Network Management Protocol (TCP/IP protocol stack)
"""
