"""
Novel's IPX
"""